import { reportData } from "@/lib/report-data";
import { SidebarNav } from "@/components/report/sidebar-nav";
import { CoverPage } from "@/components/report/cover-page";
import { ExecutiveSummary } from "@/components/report/executive-summary";
import { ScopeMethodology } from "@/components/report/scope-methodology";
import { HighRiskFinding } from "@/components/report/high-risk-finding";
import { MediumFindings } from "@/components/report/medium-findings";
import { PrivacyPolicyAnalysis } from "@/components/report/privacy-policy-analysis";
import { CookieInventory } from "@/components/report/cookie-inventory";
import { ComplianceMatrix } from "@/components/report/compliance-matrix";
import { Roadmap } from "@/components/report/roadmap";
import { NextSteps } from "@/components/report/next-steps";

export default function Page() {
  const { finding1, finding2 } = reportData;

  return (
    <div className="min-h-screen bg-[var(--cp-blue-5)]">
      <div className="mx-auto max-w-7xl px-4 py-6 lg:px-6 print-full-width">
        <div className="flex gap-6">
          {/* Sticky sidebar navigation */}
          <SidebarNav />

          {/* Main content */}
          <main className="flex-1 min-w-0 flex flex-col gap-6">
            <CoverPage />
            <ExecutiveSummary />
            <ScopeMethodology />

            <HighRiskFinding
              id="finding-1"
              number={1}
              headline={finding1.headline}
              severity={finding1.severity}
              confidence={finding1.confidence}
              confidenceReason={finding1.confidenceReason}
              observation={finding1.observation}
              legalContext={finding1.legalContext}
              businessRisk={finding1.businessRisk}
              recommendation={finding1.recommendation}
              effort={finding1.effort}
              evidence={[...finding1.topEvidence]}
              totalEvidenceCount={finding1.totalEvidenceCount}
            />

            <HighRiskFinding
              id="finding-2"
              number={2}
              headline={finding2.headline}
              severity={finding2.severity}
              confidence={finding2.confidence}
              confidenceReason={finding2.confidenceReason}
              observation={finding2.observation}
              legalContext={finding2.legalContext}
              businessRisk={finding2.businessRisk}
              recommendation={finding2.recommendation}
              effort={finding2.effort}
            />

            <MediumFindings />
            <PrivacyPolicyAnalysis />
            <CookieInventory />
            <ComplianceMatrix />
            <Roadmap />
            <NextSteps />
          </main>
        </div>
      </div>
    </div>
  );
}
